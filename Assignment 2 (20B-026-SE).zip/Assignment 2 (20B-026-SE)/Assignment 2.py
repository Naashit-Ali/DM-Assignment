#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
sns.set_style('darkgrid')


# In[3]:


data = pd.read_csv("nifty_500.csv")
data.head()


# In[4]:


data.info()


# In[5]:


object_dtype = data.select_dtypes(include=object)
object_dtype.columns


# In[6]:


num_dtype = data.select_dtypes(exclude=object)
num_dtype.columns


# In[7]:


data_shape = data.shape
print(f"The dataframe has {data_shape[0]} records and {data_shape[1]} features")


# In[8]:


data.describe().T


# In[9]:


data.describe(include=object).T


# In[10]:


sns.heatmap(data.corr(),annot=True,cmap='YlGnBu',linewidths=0.2)


# In[11]:


data.isna().any()


# In[12]:


sns.heatmap(data.isna(),annot=True)


# In[13]:


data.nunique()


# In[14]:


data.drop(columns=['Symbol','Series'],inplace=True)


# In[15]:


data.columns


# In[16]:


fx = data[['High','Low']].plot(figsize=(20,7))
fx.set_title("High vs Low",fontsize=25)


# In[17]:


fx = data[['Open','Previous Close']].plot(figsize=(20,5))
fx.set_title("Open Vs Previous Close",fontsize=20)


# In[18]:


fx = data[['52 Week High','52 Week Low']].plot(figsize=(20,5))
fx.set_title("52 Week High Vs 52 Week Low",fontsize=20)


# In[19]:


columns = ['Open','High','Previous Close','Low','Share Volume']
di = {}
plt.figure(figsize=(20,7))
plt.style.use('seaborn-white')
d_x = 231
for i in columns:
    plt.subplot(d_x)
    sns.distplot(data[i])
    a_x = plt.gcf()
    a_x.set_size_inches(11,12)
    d_x+=1
    di[i] = data[i].skew()
print("Skewness of each measures")
print(di)


# In[20]:


df = pd.DataFrame({'Open':data['Open'],'Close':data['Previous Close'],'High':data['High'],'Low':data['Low'],'Volume':data['Share Volume']})
df.plot.box(figsize=(25,7))


# In[21]:


df.plot(subplots=True,figsize=(29,15))


# In[22]:


plt.figure(figsize=(30,10))
sns.countplot(data['Industry'])
plt.xticks(rotation=90)

